# OTITO S.A.S. — Sistema web

Aplicación de demostración para la gestión de un lavadero. Los datos se guardan en `localStorage` del navegador; no se conecta a una base de datos real.

## Ejecutar

```bash
npm install
npm run dev
```

## Usuarios de demostración

- `admin` / `1234`
- `recepcion` / `1234`
- `lavador` / `1234`

## Organización del código

- `src/App.jsx`: navegación y estructura general.
- `src/pages/`: dashboard, recepción, órdenes, pagos y reportes.
- `src/pages/modules/`: un archivo separado por cada opción administrativa.
- `src/components/`: tarjetas, indicadores y barras.
- `src/data/`: datos iniciales y configuración de módulos.
- `src/hooks/`: persistencia de datos en el navegador.
- `src/utils/`: formato de moneda y etiquetas.
- `src/index.css`: estilos de la interfaz, organizados por reglas.
