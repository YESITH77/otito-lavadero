import { useState } from 'react'
import {
  LayoutDashboard,
  Car,
  ClipboardList,
  CreditCard,
  BarChart3,
  Menu,
  X,
  User,
  LogOut,
} from 'lucide-react'
import './index.css'
import useData from './hooks/useData.js'
import { modules } from './data/modules.js'
import { label } from './utils/format.js'
import Login from './pages/Login.jsx'
import Dashboard from './pages/Dashboard.jsx'
import Recepcion from './pages/Recepcion.jsx'
import Ordenes from './pages/Ordenes.jsx'
import Pagos from './pages/Pagos.jsx'
import Reportes from './pages/Reportes.jsx'
import Clientes from './pages/modules/Clientes.jsx'
import Vehiculos from './pages/modules/Vehiculos.jsx'
import Servicios from './pages/modules/Servicios.jsx'
import Categorias from './pages/modules/Categorias.jsx'
import Empleados from './pages/modules/Empleados.jsx'
import Cargos from './pages/modules/Cargos.jsx'
import Proveedores from './pages/modules/Proveedores.jsx'
import Inventario from './pages/modules/Inventario.jsx'
import Compras from './pages/modules/Compras.jsx'
import Usuarios from './pages/modules/Usuarios.jsx'

const moduleComponents = {
  clientes: Clientes,
  vehiculos: Vehiculos,
  servicios: Servicios,
  categorias: Categorias,
  empleados: Empleados,
  cargos: Cargos,
  proveedores: Proveedores,
  productos: Inventario,
  compras: Compras,
  usuarios: Usuarios,
}

function App() {
  const [data, setData] = useData()
  const [session, setSession] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('otito-session') || 'null')
    } catch {
      return null
    }
  })
  const [view, setView] = useState('dashboard')
  const [mobile, setMobile] = useState(false)

  function login(user) {
    setSession(user)
    localStorage.setItem('otito-session', JSON.stringify(user))
  }

  function go(nextView) {
    setView(nextView)
    setMobile(false)
  }

  function logout() {
    localStorage.removeItem('otito-session')
    setSession(null)
  }

  if (!session) return <Login onLogin={login} />

  const titles = {
    dashboard: 'Dashboard',
    recepcion: 'Recepción',
    ordenes: 'Órdenes',
    pagos: 'Pagos',
    reportes: 'Reportes',
  }
  const title = titles[view] || label(view)
  const Module = moduleComponents[view]

  return (
    <div className="app">
      <aside className={mobile ? 'open' : ''}>
        <div className="brand">
          <div className="brand-mark">O</div>
          <div><b>OTITO</b><small>S.A.S.</small></div>
        </div>
        <button className={view === 'dashboard' ? 'nav active' : 'nav'} onClick={() => go('dashboard')}>
          <LayoutDashboard size={17} /> Dashboard
        </button>
        <div className="nav-section">OPERACIÓN</div>
        <button className={view === 'recepcion' ? 'nav active' : 'nav'} onClick={() => go('recepcion')}>
          <Car size={17} /> Recepción
        </button>
        <button className={view === 'ordenes' ? 'nav active' : 'nav'} onClick={() => go('ordenes')}>
          <ClipboardList size={17} /> Órdenes
        </button>
        <button className={view === 'pagos' ? 'nav active' : 'nav'} onClick={() => go('pagos')}>
          <CreditCard size={17} /> Pagos
        </button>
        <div className="nav-section">ADMINISTRACIÓN</div>
        {modules.map(([key, name, Icon]) => (
          <button key={key} className={view === key ? 'nav active' : 'nav'} onClick={() => go(key)}>
            <Icon size={17} /> {name}
          </button>
        ))}
        <div className="nav-section">INFORMACIÓN</div>
        <button className={view === 'reportes' ? 'nav active' : 'nav'} onClick={() => go('reportes')}>
          <BarChart3 size={17} /> Reportes
        </button>
        <div className="sidebar-bottom">
          <span>{session.rol}</span>
          <button onClick={logout}>
            <LogOut size={14} /> Cerrar sesión
          </button>
        </div>
      </aside>
      <main className="main">
        <header className="top">
          <button
            className="hamb"
            aria-label={mobile ? 'Cerrar menú' : 'Abrir menú'}
            onClick={() => setMobile(!mobile)}
          >
            {mobile ? <X size={22} /> : <Menu size={22} />}
          </button>
          <div><b>{title}</b><span> · Sistema de gestión OTITO</span></div>
          <div className="user">
            <User size={16} /> {session.usuario}
          </div>
        </header>
        <div className="content">
          {view === 'dashboard' && <Dashboard data={data} setView={go} />}
          {view === 'recepcion' && <Recepcion data={data} setData={setData} />}
          {view === 'ordenes' && <Ordenes data={data} setData={setData} />}
          {view === 'pagos' && <Pagos data={data} setData={setData} />}
          {view === 'reportes' && <Reportes data={data} />}
          {Module && <Module data={data} setData={setData} />}
        </div>
      </main>
    </div>
  )
}

export default App
