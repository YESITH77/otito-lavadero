const money = (amount) =>
  new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    maximumFractionDigits: 0,
  }).format(amount)

const labels = {
  clientes: 'Clientes',
  vehiculos: 'Vehículos',
  servicios: 'Servicios',
  categorias: 'Categorías',
  empleados: 'Empleados',
  cargos: 'Cargos',
  proveedores: 'Proveedores',
  productos: 'Inventario',
  compras: 'Compras',
  usuarios: 'Usuarios',
}

const label = (key) => labels[key] || key

export { money, label }
