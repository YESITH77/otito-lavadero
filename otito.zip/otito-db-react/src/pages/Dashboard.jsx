import {
  Car,
  CircleDollarSign,
  Users,
  TriangleAlert,
  ClipboardList,
  CreditCard,
  Package,
  BarChart3,
  Plus,
} from 'lucide-react'
import Card from '../components/Card.jsx'
import Stat from '../components/Stat.jsx'
import Bars from '../components/Bars.jsx'
import { money } from '../utils/format.js'

function Dashboard({ data, setView }) {
  const total = data.ordenes.reduce((sum, order) => sum + order.total, 0)
  const pendientes = data.ordenes.filter((order) => order.estado !== 'Entregada').length
  const productosBajos = data.productos.filter(
    (product) => product.stock <= product.minimo,
  ).length
  const estados = Object.entries(
    data.ordenes.reduce((result, order) => {
      result[order.estado] = (result[order.estado] || 0) + 1
      return result
    }, {}),
  )

  return (
    <>
      <div className="hero">
        <div>
          <span className="eyebrow">OTITO S.A.S.</span>
          <h1>Panel de control</h1>
          <p>Una gestión más ordenada para recepción, lavado, inventario y pagos.</p>
        </div>
        <button className="primary" onClick={() => setView('recepcion')}>
          <Plus size={16} /> Nueva recepción
        </button>
      </div>
      <div className="stats">
        <Stat icon={Car} n={pendientes} t="Vehículos en proceso" />
        <Stat icon={CircleDollarSign} n={money(total)} t="Ventas registradas" />
        <Stat icon={Users} n={data.clientes.length} t="Clientes" />
        <Stat icon={TriangleAlert} n={productosBajos} t="Productos por reponer" />
      </div>
      <div className="grid2">
        <Card title="Estado de servicios">
          <Bars data={estados} />
        </Card>
        <Card title="Actividad reciente">
          <div className="timeline">
            {data.ordenes.slice(-5).reverse().map((order) => (
              <div key={order.id}>
                <b>#{order.id}</b> · {order.placa}
                <span>{order.estado} · {money(order.total)}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
      <div className="quick">
        <h2>Accesos rápidos</h2>
        <div className="quick-grid">
          <button onClick={() => setView('ordenes')}>
            <ClipboardList size={16} /> Registrar orden
          </button>
          <button onClick={() => setView('pagos')}>
            <CreditCard size={16} /> Registrar pago
          </button>
          <button onClick={() => setView('productos')}>
            <Package size={16} /> Revisar inventario
          </button>
          <button onClick={() => setView('reportes')}>
            <BarChart3 size={16} /> Ver reportes
          </button>
        </div>
      </div>
    </>
  )
}

export default Dashboard
