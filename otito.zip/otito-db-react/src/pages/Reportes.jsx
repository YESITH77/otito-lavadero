import {
  CircleDollarSign,
  ClipboardList,
  TrendingUp,
  Package,
} from 'lucide-react'
import Card from '../components/Card.jsx'
import Stat from '../components/Stat.jsx'
import Bars from '../components/Bars.jsx'
import { money } from '../utils/format.js'

function Reportes({ data }) {
  const ingresos = data.pagos.reduce((sum, payment) => sum + payment.valor, 0)
  const promedio = data.ordenes.length
    ? Math.round(data.ordenes.reduce((sum, order) => sum + order.total, 0) / data.ordenes.length)
    : 0
  const inventarioCritico = data.productos.filter(
    (product) => product.stock <= product.minimo,
  ).length
  const estados = Object.entries(data.ordenes.reduce((result, order) => {
    result[order.estado] = (result[order.estado] || 0) + 1
    return result
  }, {}))
  const reports = [
    ['Clientes registrados', data.clientes.length],
    ['Vehículos registrados', data.vehiculos.length],
    ['Órdenes por estado', estados.map(([name, count]) => `${name}: ${count}`).join(' · ')],
    ['Inventario crítico', inventarioCritico],
    ['Ingresos cobrados', money(ingresos)],
  ]
  const servicios = Object.entries(data.ordenes.reduce((result, order) => {
    result[order.servicio] = (result[order.servicio] || 0) + 1
    return result
  }, {}))

  return (
    <>
      <div className="page-title">
        <div>
          <span className="eyebrow">INFORMES</span>
          <h1>Reportes y estadísticas</h1>
          <p>Indicadores generales de operación, pagos e inventario.</p>
        </div>
      </div>
      <div className="stats">
        <Stat icon={CircleDollarSign} n={money(ingresos)} t="Ingresos cobrados" />
        <Stat icon={ClipboardList} n={data.ordenes.length} t="Órdenes" />
        <Stat icon={TrendingUp} n={money(promedio)} t="Ticket promedio" />
        <Stat icon={Package} n={inventarioCritico} t="Alertas de inventario" />
      </div>
      <div className="grid2">
        {reports.map(([title, value]) => (
          <Card key={title} title={title}><div className="report-value">{value}</div></Card>
        ))}
      </div>
      <Card title="Comparación de servicios"><Bars data={servicios} /></Card>
    </>
  )
}

export default Reportes
