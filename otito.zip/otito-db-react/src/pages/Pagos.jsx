import { useState } from 'react'
import Card from '../components/Card.jsx'
import { money } from '../utils/format.js'

function Pagos({ data, setData }) {
  const [orden, setOrden] = useState('')
  const [metodo, setMetodo] = useState('Efectivo')
  const [ok, setOk] = useState(false)

  function submit(event) {
    event.preventDefault()
    const seleccionada = data.ordenes.find((item) => item.id === Number(orden))
    if (!seleccionada) return
    setData((current) => ({
      ...current,
      pagos: [...current.pagos, {
        id: Date.now(), orden: seleccionada.id, cliente: seleccionada.cliente,
        valor: seleccionada.total, metodo, fecha: new Date().toLocaleString('es-CO'),
      }],
      ordenes: current.ordenes.map((item) =>
        item.id === seleccionada.id ? { ...item, estado: 'Entregada' } : item,
      ),
    }))
    setOk(true)
    setOrden('')
  }

  return (
    <>
      <div className="page-title">
        <div><span className="eyebrow">PROCESO</span><h1>Registro de pagos</h1>
          <p>Registra el medio de pago y cierra la orden correspondiente.</p></div>
      </div>
      {ok && <div className="success">✓ Pago registrado y orden cerrada.</div>}
      <Card title="Nuevo pago">
        <form className="form-grid" onSubmit={submit}>
          <label>Orden
            <select value={orden} onChange={(event) => setOrden(event.target.value)} required>
              <option value="">Seleccionar orden</option>
              {data.ordenes.filter((item) => item.estado === 'Lista').map((item) => (
                <option value={item.id} key={item.id}>#{item.id} · {item.placa} · {money(item.total)}</option>
              ))}
            </select>
          </label>
          <label>Método
            <select value={metodo} onChange={(event) => setMetodo(event.target.value)}>
              <option>Efectivo</option><option>Transferencia</option><option>Tarjeta</option>
            </select>
          </label>
          <div><button className="primary">Registrar pago</button></div>
        </form>
      </Card>
      <Card title="Pagos registrados">
        <div className="table-wrap"><table>
          <thead><tr><th>Orden</th><th>Cliente</th><th>Valor</th><th>Método</th><th>Fecha</th></tr></thead>
          <tbody>{data.pagos.map((payment) => (
            <tr key={payment.id}><td>#{payment.orden}</td><td>{payment.cliente}</td>
              <td>{money(payment.valor)}</td><td>{payment.metodo}</td><td>{payment.fecha}</td></tr>
          ))}</tbody>
        </table></div>
      </Card>
    </>
  )
}

export default Pagos
