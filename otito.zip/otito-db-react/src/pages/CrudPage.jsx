import { useState } from 'react'
import Card from '../components/Card.jsx'
import { label, money } from '../utils/format.js'

function CrudPage({ type, data, setData }) {
  const rows = data[type] || []
  const [query, setQuery] = useState('')
  const [page, setPage] = useState(1)
  const [editing, setEditing] = useState(null)
  const [notice, setNotice] = useState('')
  const fields = Object.keys(rows[0] || { nombre: '', descripcion: '' })
    .filter((field) => field !== 'id')
  const filtered = rows.filter((row) =>
    JSON.stringify(row).toLowerCase().includes(query.toLowerCase()),
  )
  const perPage = 5
  const pages = Math.max(1, Math.ceil(filtered.length / perPage))
  const shown = filtered.slice((page - 1) * perPage, page * perPage)

  function save(event) {
    event.preventDefault()
    const formData = new FormData(event.currentTarget)
    const record = { id: editing?.id || Date.now() }

    fields.forEach((field) => {
      record[field] = formData.get(field)
      if (['precio', 'salario', 'stock', 'minimo', 'duracion', 'total'].includes(field)) {
        record[field] = Number(record[field] || 0)
      }
    })

    setData((current) => ({
      ...current,
      [type]: editing
        ? current[type].map((row) => (row.id === editing.id ? record : row))
        : [...current[type], record],
    }))
    setEditing(null)
    setNotice(editing ? 'Registro actualizado' : 'Registro creado')
    event.currentTarget.reset()
    window.setTimeout(() => setNotice(''), 1800)
  }

  function remove(id) {
    if (!window.confirm('¿Eliminar este registro?')) return
    setData((current) => ({
      ...current,
      [type]: current[type].filter((row) => row.id !== id),
    }))
  }

  return (
    <>
      <div className="page-title">
        <div>
          <span className="eyebrow">MÓDULO CRUD</span>
          <h1>{label(type)}</h1>
          <p>Crear, consultar, editar y eliminar registros con búsqueda y paginación.</p>
        </div>
        <button className="primary" onClick={() => setEditing({})}>
          + Nuevo
        </button>
      </div>
      {notice && <div className="success">✓ {notice}</div>}
      <Card title={`Listado de ${label(type)}`}>
        <div className="toolbar">
          <input
            placeholder="Buscar..."
            value={query}
            onChange={(event) => {
              setQuery(event.target.value)
              setPage(1)
            }}
          />
          <span>{filtered.length} registros</span>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                {fields.map((field) => (
                  <th key={field}>{field.replaceAll('_', ' ')}</th>
                ))}
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {shown.map((row) => (
                <tr key={row.id}>
                  {fields.map((field) => (
                    <td key={field}>
                      {['precio', 'salario', 'valor', 'total'].includes(field)
                        ? money(Number(row[field]))
                        : String(row[field] ?? '')}
                    </td>
                  ))}
                  <td>
                    <button className="link" onClick={() => setEditing(row)}>
                      Editar
                    </button>
                    <button
                      className="link danger"
                      onClick={() => remove(row.id)}
                    >
                      Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="pagination">
          <button disabled={page === 1} onClick={() => setPage(page - 1)}>‹</button>
          <span>Página {page} de {pages}</span>
          <button disabled={page === pages} onClick={() => setPage(page + 1)}>›</button>
        </div>
      </Card>
      {editing && (
        <div className="modal">
          <form className="modal-card" onSubmit={save}>
            <div className="card-head">
              <h2>{editing.id ? 'Editar' : 'Nuevo'} {label(type)}</h2>
              <button type="button" onClick={() => setEditing(null)}>×</button>
            </div>
            <div className="form-grid">
              {fields.map((field) => (
                <label key={field}>
                  {field.replaceAll('_', ' ')}
                  <input
                    name={field}
                    defaultValue={editing[field] ?? ''}
                    required={!['correo', 'descripcion', 'telefono'].includes(field)}
                  />
                </label>
              ))}
            </div>
            <div className="actions">
              <button type="button" onClick={() => setEditing(null)}>Cancelar</button>
              <button className="primary">Guardar</button>
            </div>
          </form>
        </div>
      )}
    </>
  )
}

export default CrudPage
