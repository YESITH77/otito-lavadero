import { useState } from 'react'
import Card from '../components/Card.jsx'
import { money } from '../utils/format.js'

function Ordenes({ data, setData }) {
  const [estado, setEstado] = useState('Todos')
  const actualizarEstado = (id, nuevoEstado) => {
    setData((current) => ({
      ...current,
      ordenes: current.ordenes.map((order) =>
        order.id === id ? { ...order, estado: nuevoEstado } : order,
      ),
    }))
  }
  const ordenes = data.ordenes.filter(
    (order) => estado === 'Todos' || order.estado === estado,
  )

  return (
    <>
      <div className="page-title">
        <div>
          <span className="eyebrow">PROCESO INTEGRADO</span>
          <h1>Órdenes de servicio</h1>
          <p>Consulta las órdenes y actualiza el estado de cada vehículo.</p>
        </div>
      </div>
      <Card title="Seguimiento de vehículos">
        <div className="toolbar">
          <select value={estado} onChange={(event) => setEstado(event.target.value)}>
            <option>Todos</option><option>Recibida</option><option>En proceso</option>
            <option>Lista</option><option>Entregada</option>
          </select>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Orden</th><th>Placa</th><th>Cliente</th><th>Servicio</th><th>Fecha</th><th>Total</th><th>Estado</th></tr>
            </thead>
            <tbody>
              {ordenes.map((order) => (
                <tr key={order.id}>
                  <td>#{order.id}</td><td><b>{order.placa}</b></td><td>{order.cliente}</td>
                  <td>{order.servicio}</td><td>{order.fecha}</td><td>{money(order.total)}</td>
                  <td>
                    <select value={order.estado} onChange={(event) => actualizarEstado(order.id, event.target.value)}>
                      <option>Recibida</option><option>En proceso</option><option>Lista</option><option>Entregada</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </>
  )
}

export default Ordenes
