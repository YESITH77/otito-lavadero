import { useState } from 'react'

function Login({ onLogin }) {
  const [usuario, setUsuario] = useState('admin')
  const [contrasena, setContrasena] = useState('1234')
  const [error, setError] = useState('')

  function submit(event) {
    event.preventDefault()
    const validos = ['admin', 'recepcion', 'lavador']

    if (validos.includes(usuario) && contrasena === '1234') {
      const roles = {
        admin: 'Administrador',
        recepcion: 'Recepción',
        lavador: 'Lavador',
      }
      onLogin({ usuario, rol: roles[usuario] })
      return
    }

    setError('Usuario o contraseña incorrectos. Prueba admin / 1234.')
  }

  return (
    <div className="login">
      <div className="login-card">
        <div className="logo">OTITO<span>S.A.S.</span></div>
        <p className="muted">Sistema de gestión para lavadero</p>
        <form onSubmit={submit}>
          <label>
            Usuario
            <input
              value={usuario}
              onChange={(event) => setUsuario(event.target.value)}
              required
            />
          </label>
          <label>
            Contraseña
            <input
              type="password"
              value={contrasena}
              onChange={(event) => setContrasena(event.target.value)}
              required
            />
          </label>
          {error && <div className="error">{error}</div>}
          <button className="primary wide">Ingresar</button>
        </form>
        <small>Demo: admin / 1234 · recepción / 1234 · lavador / 1234</small>
      </div>
    </div>
  )
}

export default Login
