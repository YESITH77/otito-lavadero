import CrudPage from '../CrudPage.jsx'

function Vehiculos({ data, setData }) {
  return <CrudPage type="vehiculos" data={data} setData={setData} />
}

export default Vehiculos
