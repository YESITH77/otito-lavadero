import CrudPage from '../CrudPage.jsx'

function Compras({ data, setData }) {
  return <CrudPage type="compras" data={data} setData={setData} />
}

export default Compras
