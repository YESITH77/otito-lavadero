import CrudPage from '../CrudPage.jsx'

function Proveedores({ data, setData }) {
  return <CrudPage type="proveedores" data={data} setData={setData} />
}

export default Proveedores
