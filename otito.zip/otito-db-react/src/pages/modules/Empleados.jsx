import CrudPage from '../CrudPage.jsx'

function Empleados({ data, setData }) {
  return <CrudPage type="empleados" data={data} setData={setData} />
}

export default Empleados
