import CrudPage from '../CrudPage.jsx'

function Clientes({ data, setData }) {
  return <CrudPage type="clientes" data={data} setData={setData} />
}

export default Clientes
