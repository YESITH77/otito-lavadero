import CrudPage from '../CrudPage.jsx'

function Servicios({ data, setData }) {
  return <CrudPage type="servicios" data={data} setData={setData} />
}

export default Servicios
