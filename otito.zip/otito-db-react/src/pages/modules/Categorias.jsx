import CrudPage from '../CrudPage.jsx'

function Categorias({ data, setData }) {
  return <CrudPage type="categorias" data={data} setData={setData} />
}

export default Categorias
