import CrudPage from '../CrudPage.jsx'

function Inventario({ data, setData }) {
  return <CrudPage type="productos" data={data} setData={setData} />
}

export default Inventario
