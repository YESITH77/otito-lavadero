import CrudPage from '../CrudPage.jsx'

function Cargos({ data, setData }) {
  return <CrudPage type="cargos" data={data} setData={setData} />
}

export default Cargos
