import CrudPage from '../CrudPage.jsx'

function Usuarios({ data, setData }) {
  return <CrudPage type="usuarios" data={data} setData={setData} />
}

export default Usuarios
