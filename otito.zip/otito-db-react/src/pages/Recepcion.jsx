import { useState } from 'react'
import Card from '../components/Card.jsx'

function Recepcion({ data, setData }) {
  const [form, setForm] = useState({ placa: '', cliente: '', servicio: '', observaciones: '' })
  const [ok, setOk] = useState(false)

  function submit(event) {
    event.preventDefault()
    const servicio = data.servicios.find((item) => item.nombre === form.servicio)
    const vehiculo = data.vehiculos.find((item) => item.placa === form.placa)
    if (!vehiculo) {
      window.alert('La placa no está registrada.')
      return
    }
    setData((current) => ({
      ...current,
      ordenes: [
        ...current.ordenes,
        {
          id: Math.max(...current.ordenes.map((item) => item.id), 1000) + 1,
          placa: vehiculo.placa,
          cliente: form.cliente || vehiculo.cliente,
          servicio: servicio?.nombre || 'Servicio',
          empleado: 'Pendiente',
          fecha: new Date().toLocaleString('es-CO'),
          estado: 'Recibida',
          total: servicio?.precio || 0,
          observaciones: form.observaciones,
        },
      ],
    }))
    setOk(true)
    setForm({ placa: '', cliente: '', servicio: '', observaciones: '' })
  }

  return (
    <>
      <div className="page-title">
        <div>
          <span className="eyebrow">PROCESO</span>
          <h1>Recepción de vehículos</h1>
          <p>Formulario para registrar el ingreso antes de iniciar la orden.</p>
        </div>
      </div>
      {ok && <div className="success">✓ Vehículo recibido correctamente.</div>}
      <Card title="Nueva recepción">
        <form className="form-grid" onSubmit={submit}>
          <label>
            Placa
            <select
              value={form.placa}
              onChange={(e) => setForm({ ...form, placa: e.target.value })}
              required
            >
              <option value="">Seleccionar</option>
              {data.vehiculos.map((vehicle) => (
                <option key={vehicle.id}>{vehicle.placa}</option>
              ))}
            </select>
          </label>
          <label>
            Cliente
            <input
              value={form.cliente}
              onChange={(e) => setForm({ ...form, cliente: e.target.value })}
              placeholder="Se completa con el vehículo"
            />
          </label>
          <label>
            Servicio
            <select
              value={form.servicio}
              onChange={(e) => setForm({ ...form, servicio: e.target.value })}
              required
            >
              <option value="">Seleccionar servicio</option>
              {data.servicios.map((item) => (
                <option key={item.id}>{item.nombre}</option>
              ))}
            </select>
          </label>
          <label>
            Observaciones
            <textarea
              value={form.observaciones}
              onChange={(e) => setForm({ ...form, observaciones: e.target.value })}
            />
          </label>
          <div><button className="primary">Registrar recepción</button></div>
        </form>
      </Card>
    </>
  )
}

export default Recepcion
