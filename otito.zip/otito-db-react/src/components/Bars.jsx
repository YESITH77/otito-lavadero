function Bars({ data }) {
  const max = Math.max(...data.map((item) => item[1]), 1)

  return (
    <div className="bars">
      {data.map(([label, value]) => (
        <div className="bar-row" key={label}>
          <span>{label}</span>
          <div>
            <i style={{ width: `${(value / max) * 100}%` }} />
          </div>
          <b>{value}</b>
        </div>
      ))}
    </div>
  )
}

export default Bars
