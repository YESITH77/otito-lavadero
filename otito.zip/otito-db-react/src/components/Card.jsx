function Card({ title, children }) {
  return (
    <section className="card">
      <div className="card-head">
        <h2>{title}</h2>
      </div>
      {children}
    </section>
  )
}

export default Card
