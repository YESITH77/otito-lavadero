function Stat({ icon: Icon, n, t }) {
  return (
    <div className="stat">
      <span className="stat-icon">
        {Icon ? <Icon size={22} strokeWidth={1.8} /> : null}
      </span>
      <div>
        <strong>{n}</strong>
        <small>{t}</small>
      </div>
    </div>
  )
}

export default Stat
