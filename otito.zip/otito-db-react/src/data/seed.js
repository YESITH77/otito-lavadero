const seed = {
  clientes: [
    {
      id: 1,
      nombre: 'Carlos Mena',
      telefono: '310 555 1020',
      correo: 'carlos@email.com',
    },
    {
      id: 2,
      nombre: 'María Rentería',
      telefono: '315 222 7788',
      correo: 'maria@email.com',
    },
    {
      id: 3,
      nombre: 'Juan Palacios',
      telefono: '320 333 1144',
      correo: 'juan@email.com',
    },
  ],
  vehiculos: [
    {
      id: 1, placa: 'ABC123', cliente: 'Carlos Mena',
      tipo: 'Automóvil', marca: 'Toyota', modelo: 'Corolla', color: 'Blanco',
    },
    {
      id: 2, placa: 'XYZ789', cliente: 'María Rentería',
      tipo: 'Camioneta', marca: 'Chevrolet', modelo: 'Tracker', color: 'Negro',
    },
    {
      id: 3, placa: 'QBD456', cliente: 'Juan Palacios',
      tipo: 'Motocicleta', marca: 'Yamaha', modelo: 'FZ', color: 'Rojo',
    },
  ],
  servicios: [
    { id: 1, nombre: 'Lavado básico', categoria: 'Lavado', precio: 25000, duracion: 40 },
    { id: 2, nombre: 'Lavado premium', categoria: 'Lavado', precio: 45000, duracion: 70 },
    { id: 3, nombre: 'Polichado', categoria: 'Estética', precio: 60000, duracion: 90 },
  ],
  categorias: [
    { id: 1, nombre: 'Lavado', descripcion: 'Limpieza exterior e interior' },
    { id: 2, nombre: 'Estética', descripcion: 'Cuidado y acabado del vehículo' },
  ],
  empleados: [
    { id: 1, nombre: 'Andrés Rivas', cargo: 'Lavador', estado: 'Activo' },
    { id: 2, nombre: 'Laura Palacios', cargo: 'Recepción', estado: 'Activo' },
    { id: 3, nombre: 'Yesith Asprilla', cargo: 'Administrador', estado: 'Activo' },
  ],
  cargos: [
    { id: 1, nombre: 'Administrador', salario: 2200000 },
    { id: 2, nombre: 'Recepción', salario: 1700000 },
    { id: 3, nombre: 'Lavador', salario: 1600000 },
  ],
  proveedores: [
    { id: 1, nombre: 'Químicos del Chocó', nit: '900123456-1', telefono: '311 555 0001' },
    { id: 2, nombre: 'AutoClean', nit: '901222333-2', telefono: '320 444 0002' },
  ],
  productos: [
    {
      id: 1, codigo: 'INS-001', nombre: 'Shampoo automotriz',
      categoria: 'Químicos', stock: 24, minimo: 10, precio: 18000,
    },
    {
      id: 2, codigo: 'INS-002', nombre: 'Cera líquida',
      categoria: 'Estética', stock: 7, minimo: 10, precio: 32000,
    },
    {
      id: 3, codigo: 'INS-003', nombre: 'Paño microfibra',
      categoria: 'Accesorios', stock: 40, minimo: 15, precio: 8000,
    },
  ],
  compras: [
    { id: 1, proveedor: 'Químicos del Chocó', fecha: '2026-09-25', total: 360000 },
    { id: 2, proveedor: 'AutoClean', fecha: '2026-09-28', total: 160000 },
  ],
  ordenes: [
    {
      id: 1001, placa: 'ABC123', cliente: 'Carlos Mena',
      servicio: 'Lavado premium', empleado: 'Andrés Rivas',
      fecha: '2026-10-02 08:30', estado: 'En proceso', total: 45000,
    },
    {
      id: 1002, placa: 'XYZ789', cliente: 'María Rentería',
      servicio: 'Polichado', empleado: 'Andrés Rivas',
      fecha: '2026-10-02 09:10', estado: 'Lista', total: 60000,
    },
    {
      id: 1003, placa: 'QBD456', cliente: 'Juan Palacios',
      servicio: 'Lavado básico', empleado: 'Andrés Rivas',
      fecha: '2026-10-02 10:00', estado: 'Recibida', total: 25000,
    },
  ],
  pagos: [
    {
      id: 1, orden: 1002, cliente: 'María Rentería', valor: 60000,
      metodo: 'Transferencia', fecha: '2026-10-02 10:20',
    },
  ],
  usuarios: [
    { id: 1, usuario: 'admin', rol: 'Administrador', estado: 'Activo' },
    { id: 2, usuario: 'recepcion', rol: 'Recepción', estado: 'Activo' },
    { id: 3, usuario: 'lavador', rol: 'Lavador', estado: 'Activo' },
  ],
}

export { seed }
