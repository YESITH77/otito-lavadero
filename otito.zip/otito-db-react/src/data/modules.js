import {
  Users,
  Car,
  Sparkles,
  FolderOpen,
  Wrench,
  Briefcase,
  Building2,
  Package,
  ShoppingCart,
  Shield,
} from 'lucide-react'

const modules = [
  ['clientes', 'Clientes', Users],
  ['vehiculos', 'Vehículos', Car],
  ['servicios', 'Servicios', Sparkles],
  ['categorias', 'Categorías', FolderOpen],
  ['empleados', 'Empleados', Wrench],
  ['cargos', 'Cargos', Briefcase],
  ['proveedores', 'Proveedores', Building2],
  ['productos', 'Inventario', Package],
  ['compras', 'Compras', ShoppingCart],
  ['usuarios', 'Usuarios', Shield],
]

export { modules }
