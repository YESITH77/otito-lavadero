import { useEffect, useState } from 'react'
import { seed } from '../data/seed.js'

function useData() {
  const [data, setData] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('otito-data')) || seed
    } catch {
      return seed
    }
  })

  useEffect(() => {
    localStorage.setItem('otito-data', JSON.stringify(data))
  }, [data])

  return [data, setData]
}

export default useData
